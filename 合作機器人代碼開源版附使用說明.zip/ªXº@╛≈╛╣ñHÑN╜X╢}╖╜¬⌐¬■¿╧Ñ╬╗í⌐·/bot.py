import discord
import json
import os

from discord import option


with open("setting.json","r",encoding="utf-8")as f :
    SETTING=json.load(f)
bot=discord.Bot()

class set_generally_cooperate_button(discord.ui.View):
    def __init__(self,cl_type,cl,notify_role,command_role,tag):
        super().__init__(timeout=None)
        self.cl_type=cl_type
        self.cl=cl
        self.notify_role=notify_role
        self.command_role=command_role
        self.tag=tag
        
    @discord.ui.button(
        label="開始設定",
        style=discord.ButtonStyle.green,
        custom_id="awa:yes",
    )
    
    async def green(self, button: discord.ui.Button, interaction: discord.Interaction):
        modal = set_generally_cooperate_modal(title="宣傳文格式",cl_type=self.cl_type,
                                              cl=self.cl,
                                              notify_role=self.notify_role,
                                              command_role=self.command_role,
                                              tag=self.tag
                                              )
        await interaction.response.send_modal(modal)

class set_special_cooperate_button(discord.ui.View):
    def __init__(self,cl_type,cl,add_cl,add_cl_class,notify_role,command_role,tag):
        super().__init__(timeout=None)
        self.cl_type=cl_type
        self.cl=cl
        self.notify_role=notify_role
        self.command_role=command_role
        self.tag=tag
        self.add_cl_class=add_cl_class
        self.add_cl=add_cl
        
    @discord.ui.button(
        label="開始設定",
        style=discord.ButtonStyle.green,
        custom_id="awa:yes",
    )
    
    async def green(self, button: discord.ui.Button, interaction: discord.Interaction):
        modal = set_special_cooperate_modal(title="宣傳文格式",cl_type=self.cl_type,
                                              cl=self.cl,
                                              notify_role=self.notify_role,
                                              command_role=self.command_role,
                                              tag=self.tag,
                                              add_cl_class=self.add_cl_class,
                                              add_cl=self.add_cl
                                              )
        await interaction.response.send_modal(modal)
        
class set_special_cooperate_modal(discord.ui.Modal):
    def __init__(self, cl_type,cl,add_cl,add_cl_class,notify_role,command_role,tag, *args, **kwargs) -> None:
        self.cl_type=cl_type
        self.cl=cl
        self.notify_role=notify_role
        self.command_role=command_role
        self.tag=tag
        self.add_cl_class=add_cl_class
        self.add_cl=add_cl
        if add_cl:
            super().__init__(
                discord.ui.InputText(
                    label="合作伺服器宣傳文格式",
                    placeholder="變數小提醒: [user]:合作代表、[server]:合作伺服器名稱、[server_tag]:合作類型、[tag]:合作通知身分組)、[word]:宣傳文",
                    style=discord.InputTextStyle.long,
                ),
                discord.ui.InputText(
                    label="頻道名稱格式",
                    placeholder="變數小提醒: [server]:合作伺服器名稱",
                ),

                *args,
                **kwargs,
            )
        else:
            super().__init__(
                discord.ui.InputText(
                    label="合作伺服器宣傳文格式",
                    placeholder="變數小提醒: [user]:合作代表、[server]:合作伺服器名稱、[server_tag]:合作類型、[tag]:合作通知身分組)、[word]:宣傳文",
                    style=discord.InputTextStyle.long,
                ),
                
                *args,
                **kwargs,
            )

    async def callback(self, interaction: discord.Interaction):
        msg=await interaction.response.send_message(content="設定中...", ephemeral=True)
        try:
            server=self.children[1].value
        except:
            server=None
        data={
            "cl_type":self.cl_type,
            "cl":self.cl,
            "notify_role":self.notify_role,
            "command_role":self.command_role,
            "tag":self.tag,
            "format":self.children[0].value,
            "server":server,
            "add_cl_class":self.add_cl_class,
            "add_cl":self.add_cl
        }
        with open(f"data/special/{interaction.guild.id}.json","w+",encoding="utf-8")as f:
            json.dump(data,f)
        await msg.edit_original_response(content="設定完成")

class set_generally_cooperate_modal(discord.ui.Modal):
    def __init__(self, cl_type,cl,notify_role,command_role,tag, *args, **kwargs) -> None:
        self.cl_type=cl_type
        self.cl=cl
        self.notify_role=notify_role
        self.command_role=command_role
        self.tag=tag
        super().__init__(
            discord.ui.InputText(
                label="合作伺服器宣傳文格式",
                placeholder="變數小提醒: [user]:合作代表、[server]:合作伺服器名稱、[server_tag]:合作類型、[tag]:合作通知身分組)、[word]:宣傳文",
                style=discord.InputTextStyle.long,
            ),

            *args,
            **kwargs,
        )

    async def callback(self, interaction: discord.Interaction):
        msg=await interaction.response.send_message(content="設定中...", ephemeral=True)
        
        data={
            "cl_type":self.cl_type,
            "cl":self.cl,
            "notify_role":self.notify_role,
            "command_role":self.command_role,
            "tag":self.tag,
            "format":self.children[0].value
        }
        with open(f"data/generally/{interaction.guild.id}.json","w+",encoding="utf-8")as f:
            json.dump(data,f)
        await msg.edit_original_response(content="設定完成")
        
class generally_cooperate_modal(discord.ui.Modal):
    def __init__(self, name,user, *args, **kwargs) -> None:
        self.name=name
        self.user=user
        super().__init__(
            discord.ui.InputText(
                label="合作伺服器宣傳文",
                placeholder="輸入合作伺服器宣傳文",
                style=discord.InputTextStyle.long,
            ),

            *args,
            **kwargs,
        )

    async def callback(self, interaction: discord.Interaction):
        msg=await interaction.response.send_message(content="執行中...", ephemeral=True)
        with open(f"data/generally/{interaction.guild.id}.json","r",encoding="utf-8")as f:
            data=json.load(f)
        text=data["format"].replace("[user]",f"<@{self.user.id}>").replace("[server]",self.name).replace("[server_tag]","一般合作").replace("[tag]",f"<@&{data['notify_role']}>").replace("[word]",self.children[0].value)
        
        if data["cl_type"]=="文字頻道":
            c=await bot.fetch_channel(data["cl"])
            await c.send(text)
            await msg.edit_original_response(content="發送完成")
        else:

            c=await bot.fetch_channel(data["cl"])
            if data["tag"]:
                tags=None
                for i in c.available_tags:
                    if i.name==data["tag"]:
                        tags=[i]
                if not tags:
                    await msg.edit_original_response(content=f"我無法找到名為`{data['tag']}`的標籤，請創建標籤或重新設定後在試吧")
                    return
            else:
                tags=None
            await c.create_thread(name=self.name,content=text,applied_tags=tags)
            
            
            await msg.edit_original_response(content="創建完成")

class special_cooperate_modal(discord.ui.Modal):
    def __init__(self, name,user, *args, **kwargs) -> None:
        self.name=name
        self.user=user
        super().__init__(
            discord.ui.InputText(
                label="合作伺服器宣傳文",
                placeholder="輸入合作伺服器宣傳文",
                style=discord.InputTextStyle.long,
            ),

            *args,
            **kwargs,
        )

    async def callback(self, interaction: discord.Interaction):
        msg=await interaction.response.send_message(content="創建中...", ephemeral=True)
        with open(f"data/special/{interaction.guild.id}.json","r",encoding="utf-8")as f:
            data=json.load(f)
        text=data["format"].replace("[user]",f"<@{self.user.id}>").replace("[server]",self.name).replace("[server_tag]","一般合作").replace("[tag]",f"<@&{data['notify_role']}>").replace("[word]",self.children[0].value)
        
        if data["cl_type"]=="文字頻道":
            c=await bot.fetch_channel(data["cl"])
            await c.send(text)
            await msg.edit_original_response(content="發送完成")
        else:

            c=await bot.fetch_channel(data["cl"])
            if data["tag"]:
                tags=None
                for i in c.available_tags:
                    if i.name==data["tag"]:
                        tags=[i]
                if not tags:
                    await msg.edit_original_response(content=f"我無法找到名為`{data['tag']}`的標籤，請創建標籤或重新設定後在試吧")
                    return
            else:
                tags=None
            await c.create_thread(name=self.name,content=text,applied_tags=tags)
            
            
        if data["add_cl"]:
            channel = discord.utils.get(interaction.guild.categories, id=data["add_cl_class"])     
            cl = await interaction.guild.create_text_channel(name=data["server"].replace("[server]",self.name), category=channel)
            await cl.send(text)
        await msg.edit_original_response(content="創建完成")
@bot.event
async def on_ready():
    print(bot.user)


async def get_cl(ctx: discord.AutocompleteContext):
    if ctx.options['cl_type'] == "論壇頻道":
        l=[]
        for i in ctx.interaction.guild.forum_channels:
            l.append(f"{i.name} ({i.id})")
        return l
    else:
        l=[]
        for i in ctx.interaction.guild.text_channels:
            l.append(f"{i.name} ({i.id})")
        return l

    
@bot.slash_command(name="一般類型合作設置", description="設置一般類型合作")
async def set_generally_cooperate(ctx: discord.ApplicationContext,
                                  cl_type:discord.Option(str,"合作宣傳文發送頻道種類", choices=["文字頻道", "論壇頻道"],required=True),
                                  cl:discord.Option(description="合作宣傳文發送頻道",autocomplete=discord.utils.basic_autocomplete(get_cl),required=True),
                                  notify_role:discord.Option(discord.Role,"通知身分組設置",required=False),
                                  command_role:discord.Option(discord.Role,"允許使用指令身分組(預設包含擁有管理員權限)",required=False),
                                  tag:discord.Option(str,"論壇頻道貼文標籤",required=False)
                                  ):
    if not ctx.user.guild_permissions.administrator:
        await ctx.respond("你沒有權限", ephemeral=True)
        return
    
    cl=int(cl.split("(")[-1][:-1])
    await ctx.respond(content="""即將帶你開始設定宣傳文格式
以下是可用變數:
`[user]`:合作代表
`[server]`:合作伺服器名稱
`[server_tag]`:合作類型
`[tag]`:合作通知身分組
`[word]`:宣傳文
                      
例如合作代表是111
原始設定[user]訊息將改成@111
                      
閱讀完之後按下按鈕開始
""", ephemeral=True, view=set_generally_cooperate_button(cl_type=cl_type,cl=cl,notify_role=notify_role.id if hasattr(notify_role, 'id') else None or None,command_role=command_role.id if hasattr(command_role, 'id') else None or None,tag=tag))
    
@bot.slash_command(name="特殊類型合作設置", description="設置特殊類型合作")
async def set_special_cooperate(ctx: discord.ApplicationContext,
                                  cl_type:discord.Option(str,"合作宣傳文發送頻道種類", choices=["文字頻道", "論壇頻道"],required=True),
                                  add_cl:discord.Option(bool,"是否創建專屬頻道",required=True),
                                  cl:discord.Option(description="合作宣傳文發送頻道",autocomplete=discord.utils.basic_autocomplete(get_cl),required=True),
                                  add_cl_class:discord.Option(discord.CategoryChannel,"創建頻道類別",required=False),
                                  notify_role:discord.Option(discord.Role,"通知身分組設置",required=False),
                                  command_role:discord.Option(discord.Role,"允許使用指令身分組(預設包含擁有管理員權限)",required=False),
                                  tag:discord.Option(str,"論壇頻道貼文標籤",required=False)
                                  ):

    if not ctx.user.guild_permissions.administrator:
        await ctx.respond("你沒有權限", ephemeral=True)
        return

    cl=int(cl.split("(")[-1][:-1])
    await ctx.respond(content="""即將帶你開始設定宣傳文格式
以下是可用變數:
`[user]`:合作代表
`[server]`:合作伺服器名稱
`[server_tag]`:合作類型
`[tag]`:合作通知身分組
`[word]`:宣傳文
                      
例如合作代表是111
原始設定[user]訊息將改成@111

閱讀完之後按下按鈕開始
""", ephemeral=True, view=set_special_cooperate_button(cl_type=cl_type,
                                                       add_cl=add_cl,
                                                       add_cl_class=add_cl_class.id if hasattr(add_cl_class, 'id') else None or None,
                                                       cl=cl,
                                                       notify_role=notify_role.id if hasattr(notify_role, 'id') else None or None,
                                                       command_role=command_role.id if hasattr(command_role, 'id') else None or None,
                                                       tag=tag))
    


@bot.slash_command(name="一般類型合作",description="創建一般類型合作")
@option("user", description="合作用戶")
@option("name", description="伺服器名稱")
async def generally_cooperate(ctx:discord.ApplicationContext,user:discord.Member,name):
    if not os.path.isfile(f"data/generally/{ctx.guild.id}.json"):
        await ctx.respond("這個群組還沒設定過`一般類型合作`",ephemeral=True)
        return
    with open(f"data/generally/{ctx.guild.id}.json","r",encoding="utf-8")as f:
            data=json.load(f)
    if not (ctx.user.guild_permissions.administrator==True or data["command_role"] in ctx.user.roles):
        await ctx.respond("你沒有權限",ephemeral=True)
        return
    
    modal = generally_cooperate_modal(title="一般類型合作", user=user,name=name)
    await ctx.send_modal(modal)
    await ctx.respond(f"已開啟面板!!", ephemeral=True)

@bot.slash_command(name="特殊類型合作",description="創建特殊類型合作")
@option("user", description="合作用戶")
@option("name", description="伺服器名稱")
async def special_cooperate(ctx:discord.ApplicationContext,user:discord.Member,name):
    if not os.path.isfile(f"data/special/{ctx.guild.id}.json"):
        await ctx.respond("這個群組還沒設定過`特殊類型合作`",ephemeral=True)
        return
    with open(f"data/special/{ctx.guild.id}.json","r",encoding="utf-8")as f:
            data=json.load(f)
    if not (ctx.user.guild_permissions.administrator==True or data["command_role"] in ctx.user.roles):
        await ctx.respond("你沒有權限",ephemeral=True)
        return
    modal = special_cooperate_modal(title="特殊類型合作", user=user,name=name)
    await ctx.send_modal(modal)
    await ctx.respond(f"已開啟面板!!", ephemeral=True)
    
@bot.slash_command(name="刪除一般類型合作",description="刪除一般類型合作")
async def del_generally_cooperate(ctx:discord.ApplicationContext):
    if not ctx.user.guild_permissions.administrator:
        await ctx.respond("你沒有權限",ephemeral=True)
        return
    try:
        os.remove(f"data/generally/{ctx.guild.id}.json")
        await ctx.respond("`一般類型合作`設定已刪除",ephemeral=True)
    except:
        await ctx.respond(f"這個群組還沒設定過`一般類型合作`",ephemeral=True)
        
@bot.slash_command(name="刪除特殊類型合作",description="刪除特殊類型合作")
async def del_special_cooperate(ctx:discord.ApplicationContext):
    if not ctx.user.guild_permissions.administrator:
        await ctx.respond("你沒有權限",ephemeral=True)
        return
    try:
        os.remove(f"data/special/{ctx.guild.id}.json")
        await ctx.respond("`特殊類型合作`設定已刪除",ephemeral=True)
    except:
        await ctx.respond(f"這個群組還沒設定過`特殊類型合作`",ephemeral=True)
        
bot.run(SETTING["token"])